/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package artgallery;


public class ArtGallery {

    private int id;
    private String ord_type;
    private String description;
    private float price;
    private byte[] picture;
    
    public ArtGallery(int pid, String pord_type, String pdescription, float pprice, byte[] pimg){
        
        this.id = pid;
        this.ord_type = pord_type;
        this.description = pdescription;
        this.price = pprice;
        this.picture = pimg; 
    }
    
    public int getId(){
        return id;
    }
    
    public String getName(){
        return ord_type;
    }
    
    public String getDescription(){
        return description;
    }
    
    public float getPrice(){
        return price;
    }
    
    public byte[] getImage(){
        return picture;
    } 
        
}